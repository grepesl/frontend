class Calculator{
    constructor(){

    }
    
    sum(num1, num2) {
      return num1 + num2;  
    }

    subtraction(num1, num2) {
      return num1 - num2;
    }

    multiplication(num1, num2) {
      return num1 * num2;
    } 

    division(num1, num2) {
      return num1 / num2;
    }
  }

  export default Calculator;