function composition(a, b) {
  return a + b;
}

export default composition;