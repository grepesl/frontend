function division(a, b) {
  return a / b;
}

export default division;