function multiplication(a, b) {
  return a * b;
}

export default multiplication;